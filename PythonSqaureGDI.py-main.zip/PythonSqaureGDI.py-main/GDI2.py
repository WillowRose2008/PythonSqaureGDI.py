w1 = lower_right_x1 - upper_left_x1
   = i + w0 - n - (i + n)
   = w0 - (2 * n)
