# PythonSqaureGDI.py
Python code i found for GDI sqaure effect
